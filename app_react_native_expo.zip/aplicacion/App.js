import React, { Component } from 'react';
import {createStackNavigator, createAppContainer, } from 'react-navigation';
import HomeScreen from './components/HomeScreen';
import Localizacion from './components/Localizacion';
import Menu from './components/menu';
import Contacto from './components/Contacto';
import Web from './components/Web';
import Portfolio from './components/Portfolio';

const MainNavigator = createStackNavigator({
  Home: {screen: HomeScreen},
  Localizacion: {screen: Localizacion},
  Menu: {screen: Menu},
  Contacto: {screen: Contacto},
  Web: {screen: Web},
  Portfolio: {screen: Portfolio},
});

const App = createAppContainer(MainNavigator);

export default App;