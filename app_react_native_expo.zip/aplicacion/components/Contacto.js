import React from 'react';
import { Text, View, RouteConfigs, MaterialBottomTabNavigatorConfig, StyleSheet, ImageBackground, Button, Linking } from 'react-native';
import { createBottomTabNavigator, createAppContainer } from 'react-navigation';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MapView from 'react-native-maps';
import call from 'react-native-phone-call';
const styles = StyleSheet.create({
    container:{
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
      justifyContent: 'flex-end',
      alignItems: 'center',
    },
    map:{
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
    },
    fondo:{
      width: '100%',
      height: '100%',
      alignItems: 'center',
    },
    texto: {
      color:'white',
      marginTop: 10,
      fontSize:15
    },
    titulo: {
      color:'white',
      fontWeight: 'bold',
      marginTop: 10,
      fontSize:20
    }
  });

class Datos extends React.Component {
  llamar = () => {
      const args = {
      number: '958453465',
      prompt: false,
    };
    call(args).catch(console.error);
  }
  email = () =>{
     Linking.openURL('mailto:support@example.com');
  }
  render() {
    return (
      <View>
        <ImageBackground source={require('assets/fondo.jpg')} style={styles.fondo}>
         <Text style={styles.titulo}>Datos de contacto</Text>

         <Text style={styles.texto} onPress={this.llamar} ><Ionicons name={'ios-phone-portrait'} size={25} color={'white'} /> 958452312</Text>
         <Text style={styles.texto}  onPress={this.email}><Ionicons name={'ios-at'} size={25} color={'white'} /> info@tienda.com</Text>

         
         <Text style={styles.texto}><Ionicons name={'ios-mail'} size={25} color={'white'} /> Av. Doctor Oloriz, 11</Text>
         <Text style={styles.texto}>18002, Granada</Text>
         <Text style={styles.texto}>España</Text>
        </ImageBackground>
      </View>
    );
  }
}

class Localizacion extends React.Component {
  render() {
    return (
       <View style={styles.container}>
        <MapView style={styles.map}
          region={{
            latitude: 37.187305,
            longitude: -3.607884,
            latitudeDelta: 0.005,
            longitudeDelta: 0.005,
          }}
        >
         <MapView.Marker coordinate={{
                          latitude: 37.187305,
                          longitude: -3.607884,
                        }}
        title={'EAG'}
        description={'¡Aquí estamos!'}
        />
        </MapView>
      </View>
    );
  }
}

const TabNavigator = createBottomTabNavigator(
  {
  Datos: {
        screen: Datos,
        path: '/',
        navigationOptions: {
            title:'Datos',
            tabBarIcon: ({tintColor}) => <Ionicons name='ios-information-circle' color={tintColor} size={25}/>,
            tabBarOptions: { activeTintColor:'red', }
        },
    },
  Localizacion:{
        screen: Localizacion,
        path: '/',
        navigationOptions: { 
            title:'¡Encuéntranos!',
            tabBarIcon: ({tintColor}) => <Ionicons name='ios-map' color={tintColor} size={25}/>,
            tabBarOptions: { activeTintColor:'red', }
        },
    },
},
);

const AppContainer = createAppContainer(TabNavigator);

export default class App extends React.Component {
  static navigationOptions = {
    title: 'Contacto',
    headerStyle: {
      backgroundColor: '#f4511e',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      flex:0.8,
      textAlign: 'center',
      alignSelf: 'center',
    },
    headerBackTitle:null,
    headerTruncatedBackTitle: null,
  };
  render() {
    return <AppContainer />;
  }
}

//export default createAppContainer(TabNavigator);
