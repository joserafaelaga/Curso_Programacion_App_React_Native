import React from 'react';
import { View, Text, StyleSheet, ImageBackground,TouchableHighlight, } from 'react-native';
const styles = StyleSheet.create({
  container: {
     width: '100%',
    height: '100%',
    alignItems: 'center',
  },
  button: {
    alignItems: 'center',
    backgroundColor: 'red',
    padding: 10, 
    borderColor: 'white',
    borderWidth:1,
    width:200,
    marginTop: 20,
  },
  textButton:{
    color:'white'
  },
});

export default class menu extends React.Component {
 static navigationOptions = ({ navigation }) => {
   const nombre = navigation.getParam('name', 'Usuario');
    return {
      title: '¡Bienvenido '+nombre.text+'!',
      headerStyle: {
        backgroundColor: '#f4511e',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        flex:1,
        textAlign: 'center',
        alignSelf: 'center',
      },
      headerBackTitle:'Menú', //Definir en origen, no en destino
      headerTruncatedBackTitle: 'Menú', //Definir en origen, no en destino
      headerLeft: null //Deshabilitar botón atrás
    };
  };
  render() {  
    const {navigate} = this.props.navigation;
    return (
      <View>
       <ImageBackground source={require('assets/fondo.jpg')} style={styles.container}>
          <TouchableHighlight
            style={styles.button}
            onPress={() => navigate('Portfolio')}
          >
            <Text style={styles.textButton}> PRODUCTOS </Text>
          </TouchableHighlight>
           <TouchableHighlight
            style={styles.button}
            onPress={() => navigate('Web')}
          >
            <Text style={styles.textButton}> NUESTRA WEB </Text>
          </TouchableHighlight>
           <TouchableHighlight
            style={styles.button}
            onPress={() => navigate('Contacto')}
          >
            <Text style={styles.textButton}> CONTACTO </Text>
          </TouchableHighlight>
        </ImageBackground>
      </View>
    );
  }
}