import React from 'react';
import { View, Text, Button, StyleSheet, TextInput, AppRegistry,ImageBackground } from 'react-native';

const styles = StyleSheet.create({
  fondo:{
    width: '100%',
    height: '100%',
    alignItems: 'center',
  },
  texto: {
    color: 'white',
    fontWeight: 'bold',
    marginTop: 20,
    paddingLeft: 10,
    marginBottom:20, 
    fontSize: 20
  },
  input: {
    paddingLeft: 10,
    marginBottom:20,
    fontSize: 15, 
    color: 'white',
    borderColor: 'white',
    borderWidth:1,
    width:300,
    height: 40,
  },
  error:{
    color: "white",
    fontWeight: 'bold',
    paddingLeft: 10,
    paddingBottom: 20,
  }
});

export default class HomeScreen extends React.Component {
   constructor(props) {
    super(props);
    this.state = {text: ''};
  }
  static navigationOptions = {
    title: 'Tienda',
    headerStyle: {
      backgroundColor: '#f4511e',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      flex:1,
      textAlign: 'center',
      alignSelf: 'center',
    },
    headerBackTitle:null,
    headerTruncatedBackTitle: null
  };
  render() {
    const {navigate} = this.props.navigation;
    return (
      <View>
      <ImageBackground source={require('assets/fondo.jpg')} style={styles.fondo}>
        <Text style={styles.texto}>¿Cuál es tu nombre?</Text>
         <TextInput style={styles.input}
          onChangeText={(text) => this.setState({text})}
          placeholder="Introduce tu nombre"
          placeholderTextColor = "white" //Para que se vea en iOS
          />
          {!!this.state.nameError && (
          <Text style={styles.error}>{this.state.nameError}</Text>
         )}
          <Button
            title="Continuar"
            color="red"
            onPress={() => {
              if (this.state.text.trim() === "") {
                this.setState(() => ({ nameError: "Necesitamos tu nombre para poder continuar ;)" }));
              } else {
                navigate('Menu', {name: {text:this.state.text}})}
              }
            }
            //onPress={() => this.props.navigation.navigate('Detail')}
          />
        </ImageBackground>
      </View>
    );
  }
}