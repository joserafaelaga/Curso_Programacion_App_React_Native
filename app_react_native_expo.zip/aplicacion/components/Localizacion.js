import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import MapView from 'react-native-maps';
const styles = StyleSheet.create({
    container:{
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
      justifyContent: 'flex-end',
      alignItems: 'center',
    },
    map:{
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
    }
  });
export default class Localizacion extends React.Component {
 static navigationOptions = ({ navigation }) => {
    return {
      title: '¡Encuéntranos!',
      headerStyle: {
        backgroundColor: '#f4511e',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        flex:0.8,
        textAlign: 'center',
        alignSelf: 'center',
      },
    };
  };
  render() {  
    return (
      <View style={styles.container}>
        <MapView style={styles.map}
          region={{
            latitude: 37.187305,
            longitude: -3.607884,
            latitudeDelta: 0.005,
            longitudeDelta: 0.005,
          }}
        >
         <MapView.Marker coordinate={{
                          latitude: 37.187305,
                          longitude: -3.607884,
                        }}
        title={'EAG'}
        description={'¡Aquí estamos!'}
        />
        </MapView>
      </View>
    );
  }
}