import React, {Component} from 'react';
import {View, WebView, StyleSheet} from 'react-native';

const styles = StyleSheet.create({

});
export default class Web extends React.Component {
 static navigationOptions = ({ navigation }) => {
    return {
      title: 'Nuestra web',
      headerStyle: {
        backgroundColor: '#f4511e',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
       flex:0.8,
       textAlign: 'center',
        alignSelf: 'center',
      },
    };
  };
  render() {  
    return (
         <WebView
            source={{uri: 'https://www.escuelaartegranada.com/'}}
          />
    );
  }
}