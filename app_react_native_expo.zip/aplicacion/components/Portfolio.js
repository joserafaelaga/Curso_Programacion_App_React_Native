import React, { Component } from 'react';
import { AppRegistry,View,Text,
StyleSheet,FlatList,Image,StatusBar,
TouchableOpacity,TouchableHighlight, RefreshControl } from 'react-native';

export default class portfolio extends Component{
	static navigationOptions= ({navigation}) =>({
		  title: 'Portfolio',
       headerStyle: {
        backgroundColor: '#f4511e',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        flex:0.8,
        textAlign: 'center',
        alignSelf: 'center',
      },
		});


	state={
		data:[],
		refreshing: false

	};
	fetchData = async() =>{
		const { params } = this.props.navigation.state;
		const response =  await fetch('https://joserafaelaguilera.com/movies.json');
		const portfolio = await response.json(); // products have array data
		this.setState({data: portfolio.movies}); // filled data with dynamic array
	};
	componentDidMount(){
		this.fetchData();
	}
	_onRefresh(){
		this.setState({refreshing: true});
		this.fetchData().then(() =>{
			this.setState({refreshing: false})
		});
	}

	render(){
		 const {navigate} = this.props.navigation;
  //onPress={() => navigate('Contacto', {id: item.id})}
		return(
		 <View style={styles.container}>
		  <FlatList
		  data={this.state.data}
		  keyExtractor={(x,i) => i}
		  renderItem={({item})=>
		  <View style={styles.productBox}>
		  <Image style={{height:250, width:'100%'}} source={{uri: item.image}} />
		   <Text style={styles.price}>{item.releaseYear}</Text>
		  <Text style={styles.proName}>{item.title}</Text>
		  <TouchableHighlight
		  title="Ver detalles"
      style={styles.button}
		  onPress={() => navigate('Contacto')}>
		    <Text style={styles.textButton}> VER </Text>
      </TouchableHighlight>
		  </View>
		  }
		  refreshControl={
			  <RefreshControl
			  refreshing = {this.state.refreshing}
			  onRefresh={this._onRefresh.bind(this)}
			  />
		  }
		   />
		</View>
		);
	}



}
const styles = StyleSheet.create({
	container:{
		 flex: 1,
        flexDirection: 'column',
		justifyContent: 'center',

	},
	productBox:{
		padding:5,margin:10,borderColor:'orange',borderBottomWidth:1
	},
	price:{
		padding:5, color:'orange',fontWeight:'bold',textAlign:'center'
	},
	proName:{
		padding:5,color:'blue',textAlign:'center'
	},
  button: {
    alignItems: 'center',
    backgroundColor: '#FE6F61',
    padding: 5, 
    borderColor: 'white',
    borderWidth:1,
    marginTop: 20,
  },
  textButton:{
    color:'white'
  },
})
AppRegistry.registerComponent('portfolio', () => portfolio);